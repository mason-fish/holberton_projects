name "normal"
description "cookbook that does not depend on compat_resource"
version "1.0.0"
